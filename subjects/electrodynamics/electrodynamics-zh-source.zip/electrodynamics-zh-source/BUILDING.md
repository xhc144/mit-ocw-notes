XeLaTeX + ctex/xeCJK + Fandol + Computer Modern Unicode are required. Fonts are runtime dependencies, not bundled.
Run python vendor/math-latex-typesetting/scripts/validate.py main.tex --out build
The source ZIP does not require English source PDFs or a network connection.
