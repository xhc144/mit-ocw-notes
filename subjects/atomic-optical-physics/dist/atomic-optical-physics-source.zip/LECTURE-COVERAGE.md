# 两门核心课逐讲覆盖

状态区分实质主题重编和先修衔接；不是逐句转写承诺。选读6.974、6.453不计全课完成。

| 课/讲 | 章 | 实際推导/任务 |
|---|---|---|
| 8.421 Spring 2014 L1 | 1 | 二能级旋转Hamiltonian、共振与失谐 |
| 8.421 Spring 2014 L2 | 1 | Rabi矩阵指数、旋转参考系、脉冲概率 |
| 8.421 Spring 2014 L3 | 1 | Ramsey相位与两脉冲干涉 |
| 8.421 Spring 2014 L4 | 1 | 回波、绝热跟随与共振读出 |
| 8.421 Spring 2014 L5 | 1–2 | 共振尺度与真实原子能量层级 |
| 8.421 Spring 2014 L6 | 2 | 多电子变分、交换与自旋 |
| 8.421 Spring 2014 L7 | 2 | 精细结构、有限核、Welton领先对数 |
| 8.421 Spring 2014 L8 | 2–3 | 角动量与超精细结构 |
| 8.421 Spring 2014 L9 | 2–3 | 量子亏损、弱/强场态 |
| 8.421 Spring 2014 L10 | 3 | Zeeman、Landé与Breit--Rabi块 |
| 8.421 Spring 2014 L11 | 3 | Stark混合、宇称、分子转动偶极 |
| 8.421 Spring 2014 L12 | 3–4 | 磁/电场与偶极辐射接口 |
| 8.421 Spring 2014 L13 | 4 | 最小耦合到电偶极、选择规则 |
| 8.421 Spring 2014 L14 | 4 | 经典/量子驱动、旋波与反旋 |
| 8.421 Spring 2014 L15 | 4–5 | 发射率、Einstein系数、模式密度 |
| 8.421 Spring 2014 L16 | 5 | 开放二能级、饱和与寿命 |
| 8.421 Spring 2014 L17 | 5–6 | 衰减相关与线宽 |
| 8.421 Spring 2014 L18 | 6 | 自然、碰撞和Doppler线型 |
| 8.421 Spring 2014 L19 | 6 | Gaussian/Lorentz/Voigt卷积及展宽机制 |
| 8.421 Spring 2014 L20 | 6–7 | 非均匀展宽及双光子中间态 |
| 8.421 Spring 2014 L21 | 7 | 双光子失谐、有效耦合 |
| 8.421 Spring 2014 L22 | 7 | 密度矩阵相干、暗态 |
| 8.421 Spring 2014 L23 | 7 | Raman/EIT与路径相干 |
| 8.421 Spring 2014 L24 | 7 | 相干操控的近似条件 |
| 8.421 Spring 2014 L25 | 7 | 干涉、暗态与实验读数 |
| 8.422 Spring 2013 L1 | 8–14 | 专题结构与先修衔接，基础原子结构沿用1–7章 |
| 8.422 Spring 2013 L2 | 4、8 | 量子模式与偶极Hamiltonian，省略重复基础推导 |
| 8.422 Spring 2013 L3 | 8 | 量子光场、相干/数态与Q函数 |
| 8.422 Spring 2013 L4 | 8 | 压缩Bogoliubov变换、矩与损耗 |
| 8.422 Spring 2013 L5 | 8 | 单光子与非经典计数统计 |
| 8.422 Spring 2013 L6 | 9 | Schmidt、传态与纯态纠缠 |
| 8.422 Spring 2013 L7 | 9 | Mach--Zehnder、误差传播、Yurke与散粒噪声 |
| 8.422 Spring 2013 L8 | 8–9 | 二阶相关、HBT、原子交换干涉 |
| 8.422 Spring 2013 L9 | 10 | 虚激发、极化率、色散力图像 |
| 8.422 Spring 2013 L10 | 10 | 二阶van der Waals与延迟尺度 |
| 8.422 Spring 2013 L11 | 10 | 平行板模式和、背景扣除、Euler--Maclaurin压力 |
| 8.422 Spring 2013 L12 | 10 | 共振交换与Jaynes--Cummings流形 |
| 8.422 Spring 2013 L13 | 5 | 主方程、Bloch方程和稳态 |
| 8.422 Spring 2013 L14 | 5、10 | Bloch极点、相干/非相干Mollow谱权重与峰宽 |
| 8.422 Spring 2013 L15 | 5 | 跳跃、无跳跃演化、记录与非唯一unravelling |
| 8.422 Spring 2013 L16 | 12 | 散射/偶极力、反冲与力相关扩散 |
| 8.422 Spring 2013 L17 | 10、12 | 缀饰支、随机切换、滞后摩擦和实际Sisyphus循环 |
| 8.422 Spring 2013 L18 | 13 | 蒸发能量账、效率、碰撞率幂律与runaway条件 |
| 8.422 Spring 2013 L19 | 13 | GP、愈合长度、TF、Bogoliubov耗尽、Mott平均场边界 |
| 8.422 Spring 2013 L20 | 13 | Fermi面、Cooper对数、BCS波函数/隙/粒子数与BEC跨越 |
| 8.422 Spring 2013 L21 | 14 | Paul阱、边带、Cirac--Zoller三脉冲与几何相位门 |
