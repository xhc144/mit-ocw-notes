# 量子力学中文学习册独立源码

所有 TeX 输入、数值图坐标和固定适配类均在本 ZIP 内；字体和 TeX Live 为运行环境依赖。
在本目录执行：

    python tools/build.py --out build
    python tools/check_pdf.py build/main.pdf --out build/pdf-links.json

完整依赖与限制见 BUILDING.md。

本册是 MIT OCW Barton Zwiebach 8.04 Spring 2016、8.05 Fall 2013、8.06 Spring 2018 的非官方中文改编。新增推导与答案为 AI 独立整理，没有取得官方答案。原件另署 Sarah Geller、Andrew Turner 的转录信用在来源附录保留。CC BY-NC-SA 4.0；商业教材未打包，纯教材题号不编造题面。课程入口与逐项资源链接均在 PDF 来源附录。

图文件为自主数值计算生成；普通编译不需要 SciPy 或网络。可选重算图形依赖 NumPy/SciPy，输出的采样不能替代解析证明。
