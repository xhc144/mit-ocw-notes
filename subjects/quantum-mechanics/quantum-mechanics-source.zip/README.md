# 量子力学中文学习册源码

17章理论与19份考核题解、全部112道大题的小问。按 BUILDING.md 用 XeLaTeX 编译 main.tex。每章来源及覆盖边界见 coverage.json 与册末，全部题解为 AI 独立解答。完整来源原件、独立内容复核与逐页视觉记录在公开仓库 subjects/quantum-mechanics/qa/；本ZIP不包含英文原件、字体或商业教材。
