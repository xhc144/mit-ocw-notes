# 常微分方程与动力系统：中文源码

此包仅包含中文原生 LaTeX 正文、锁定王者模板、必要构建代码及许可来源。
英文课程原件、网页、完整来源清单和审稿记录保留于仓库，不在此包内。
全部图形在 TeX 中以 TikZ/PGF 独立构造；重编无需下载或嵌入任何课程原件。

需要 Python 3.11+、XeLaTeX 与常规 TeX Live 宏包。先安装构建依赖：

```bash
python -m pip install -r vendor/math-latex-typesetting/requirements.txt
python tools/bootstrap_tex.py --texmf-dir .runtime/texmf --cache-dir .runtime/downloads
TEXMFHOME="$PWD/.runtime/texmf" bash tools/build.sh
```

已有 Fandol、CM Unicode 与 ctex 环境时可直接指定 TEXMFHOME 后执行构建。
字体与运行依赖不随包分发；引导脚本使用固定版本并验证下载哈希。
输出为 ordinary-differential-equations.pdf；main.tex 内含实际锁定类文件。
课程署名、编者补充和未公开教材题面边界见 SOURCES.md 与正文；许可见 LICENSE.md。
